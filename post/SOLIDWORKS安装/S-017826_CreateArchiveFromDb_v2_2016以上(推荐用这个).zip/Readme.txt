ArcServCreator - v2 (2016)
==========================
For use with:
- SOLIDWORKS PDM 2016 and newer (Professional and Standard)
- Enterprise PDM 2015 and older (64-bit only)

This utility makes it easier to set up a customer vault for testing.

1. Restore the customer's database backup on the SQL server.
- Note that you also need ConisioMasterDb if not already present on the SQL server.
2. Extract the files from "CreateArchiveFromDb_v2_2016.zip" to a local folder on the Archive server.
3. Right-click "ArcServCreator_V2.exe" and select "Run as Administrator".
4. Fill in SQL details and the path to the archive root folder.
5. Click "Create" to create the archive server settings for the restored vault.

Notes:
- The tool will create the archive folders and registry keys needed to log in on the vault.
- The tool will not create any physical archive files, just the empty folder structure.
- The tool will not create any of the user logins present in the restored database so you will initially have to log in as Admin.
- If the vault you are restoring is replicated and you intend to keep it as a replicated vault, remember to add registry flag "Replicate" with value 1. 