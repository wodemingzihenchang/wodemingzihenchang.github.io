ArcServCreator
==============

This utility makes it easier to set up a customer vault for testing.

1. Restore the customer's database backup
2. Run the tool on the archive server - use appropriate 32-bit or 64-bit version depending on operating system.

The tool will create the archive folders and registry keys needed to log in on the vault.

It will not create any archive files, just empty folders.
It will currently not create the users present in the database on the archive server so you will initially have to log in as Admin. (Perhaps extend it in the future?)